package com.dicoding.ajp_dicoding1.model

@Parcelize
data class Movies (
    val id: String,
    val title: String,
    val overview: String,
    val duration: String,
    val genre: String,
    val poster: Int
) :